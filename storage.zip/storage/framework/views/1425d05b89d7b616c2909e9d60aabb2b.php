<?php $__env->startSection('title',translate('messages.business_Modules')); ?>

<?php $__env->startPush('css_or_js'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content container-fluid">
        <!-- Page Header -->
        <div class="page-header d-flex flex-wrap align-items-center justify-content-between">
            <h1 class="page-header-title">
                <span class="page-header-icon">
                    <img src="<?php echo e(asset('public/assets/admin/img/module.png')); ?>" alt="">
                </span>
                <span>
                    <?php echo e(translate('messages.business_Module_list')); ?>

                </span>
            </h1>
            <div class="text--primary-2 d-flex flex-wrap align-items-center" type="button" data-toggle="modal" data-target="#warning-status-modal">
                <strong class="mr-2"><?php echo e(translate('How it Works')); ?></strong>
                <div class="blinkings">
                    <i class="tio-info-outined"></i>
                </div>
            </div>
        </div>
        <!-- End Page Header -->
        <div class="card">
            <!-- Header -->
            <div class="card-header border-0 py-2">
                <div class="search--button-wrapper">
                    <form class="search-form mr-auto">
                        <!-- Search -->
                        <div class="input-group input--group">
                            <input id="datatableSearch" name="search" type="search" class="form-control" placeholder="<?php echo e(translate('ex_:_Search_Module_by_Name')); ?>" aria-label="<?php echo e(translate('messages.search_here')); ?>" value="<?php echo e(request()->query('search')); ?>">
                            <button type="submit" class="btn btn--secondary"><i class="tio-search"></i></button>
                            <?php if(request()->get('search')): ?>
                            <button type="reset" class="btn btn--primary ml-2 location-reload-to-base" data-url="<?php echo e(url()->full()); ?>"><?php echo e(translate('messages.reset')); ?></button>
                            <?php endif; ?>
                        </div>
                        <!-- End Search -->
                    </form>




                    <div>
                        <select id="module_type" name="module_type" class="form-control h--45px set-filter" data-url="<?php echo e(url()->full()); ?>" data-filter="module_type">
                            <option value="all" <?php echo e(request('module_type') == 'all' ? 'selected' : ''); ?>><?php echo e(translate('messages.all_module_type')); ?></option>
                            <?php $__currentLoopData = config('module.module_type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option class="" value="<?php echo e($key); ?>" <?php echo e(request('module_type') == $key ? 'selected' : ''); ?>><?php echo e(translate($key)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="hs-unfold mr-2">
                        <a class="js-hs-unfold-invoker btn btn-sm btn-white dropdown-toggle min-height-40" href="javascript:;"
                            data-hs-unfold-options='{
                                    "target": "#usersExportDropdown",
                                    "type": "css-animation"
                                }'>
                            <i class="tio-download-to mr-1"></i> <?php echo e(translate('messages.export')); ?>

                        </a>

                        <div id="usersExportDropdown"
                            class="hs-unfold-content dropdown-unfold dropdown-menu dropdown-menu-sm-right">
                            <span class="dropdown-header"><?php echo e(translate('messages.download_options')); ?></span>
                            <a id="export-excel" class="dropdown-item" href="<?php echo e(route('admin.business-settings.module.export', ['type'=>'excel',request()->getQueryString()])); ?>">
                                <img class="avatar avatar-xss avatar-4by3 mr-2"
                                    src="<?php echo e(asset('public/assets/admin')); ?>/svg/components/excel.svg"
                                    alt="Image Description">
                                <?php echo e(translate('messages.excel')); ?>

                            </a>
                            <a id="export-csv" class="dropdown-item" href="<?php echo e(route('admin.business-settings.module.export', ['type'=>'csv',request()->getQueryString()])); ?>">
                                <img class="avatar avatar-xss avatar-4by3 mr-2"
                                    src="<?php echo e(asset('public/assets/admin')); ?>/svg/components/placeholder-csv-format.svg"
                                    alt="Image Description">
                                .<?php echo e(translate('messages.csv')); ?>

                            </a>
                        </div>
                    </div>
                    <a href="<?php echo e(route('admin.business-settings.module.create')); ?>" class="btn btn--primary">+ <?php echo e(translate('Add New Module')); ?></a>
                    <!-- End Unfold -->
                </div>
                <!-- End Row -->
            </div>
            <!-- End Header -->
            <div class="card-body p-0">
                <div class="table-responsive datatable-custom">
                    <table id="columnSearchDatatable"
                        class="table table-borderless table-thead-bordered table-align-middle"
                        data-hs-datatables-options='{
                            "isResponsive": false,
                            "isShowPaging": false,
                            "paging":false,
                        }'>
                        <thead class="thead-light border-0">
                            <tr>
                                <th class="border-0 pl-4 w--05"><?php echo e(translate('messages.sl')); ?></th>
                                <th class="border-0 w--1"><?php echo e(translate('messages.module_id')); ?></th>
                                <th class="border-0 w--2"><?php echo e(translate('messages.name')); ?></th>
                                <th class="border-0 w--2"><?php echo e(translate('messages.business_Module_type')); ?></th>
                                <th class="border-0 text-center w--2"><?php echo e(translate('messages.total_vendors')); ?></th>
                                <th class="border-0 w--1"><?php echo e(translate('messages.status')); ?></th>
                                <th class="border-0 text-center w--15"><?php echo e(translate('messages.action')); ?></th>
                            </tr>
                        </thead>

                        <tbody id="table-div">
                        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($module->module_type == 'rental' && addon_published_status('Rental') == 1) || $module->module_type != 'rental'): ?>
                            <tr>
                                <td class="pl-4"><?php echo e($key+$modules->firstItem()); ?></td>
                                <td><?php echo e($module->id); ?></td>
                                <td>
                                    <span class="d-block font-size-sm text-body">
                                        <?php echo e(Str::limit(translate($module['module_name']), 20,'...')); ?>

                                    </span>
                                </td>
                                <td>
                                    <span class="d-block font-size-sm text-body text-capitalize">
                                        <?php echo e(Str::limit(translate($module['module_type']), 20,'...')); ?>

                                    </span>
                                </td>
                                <td class="text-center">
                                    <?php echo e($module->stores->filter(function($store) {
                                        return $store->vendor && $store->vendor->status == 1;
                                    })->count()); ?>

                                </td>
                                <td>
                                    <label class="toggle-switch toggle-switch-sm" for="status-<?php echo e($module->id); ?>">
                                    <input type="checkbox" class="toggle-switch-input dynamic-checkbox"
                                           data-id="status-<?php echo e($module->id); ?>"
                                           data-type="status"
                                           data-image-on='<?php echo e(asset('/public/assets/admin/img/modal')); ?>/module-on.png'
                                           data-image-off="<?php echo e(asset('/public/assets/admin/img/modal')); ?>/module-off.png"
                                           data-title-on="<?php echo e(translate('Want_to_activate_this')); ?> <strong><?php echo e(translate('Business_Module?')); ?></strong>"
                                           data-title-off="'<?php echo e(translate('Want_to_deactivate_this')); ?> <strong><?php echo e(translate('Business_Module?')); ?></strong>"
                                           data-text-on="<p><?php echo e(translate('If_you_activate_this_business_module,_all_its_features_and_functionalities_will_be_available_and_accessible_to_all_users.')); ?></p>"
                                           data-text-off="<p><?php echo e(translate('If_you_deactivate_this_business_module,_all_its_features_and_functionalities_will_be_disabled_and_hidden_from_users.')); ?></p>"

                                    class="toggle-switch-input" id="status-<?php echo e($module->id); ?>" <?php echo e($module->status?'checked':''); ?>>
                                        <span class="toggle-switch-label">
                                            <span class="toggle-switch-indicator"></span>
                                        </span>
                                    </label>
                                    <form action="<?php echo e(route('admin.business-settings.module.status',[$module['id'],$module->status?0:1])); ?>" method="get" id="status-<?php echo e($module->id); ?>_form">
                                    </form>
                                </td>
                                <td>
                                    <div class="btn--container justify-content-center">
                                        <a class="btn action-btn btn--primary btn-outline-primary"
                                            href="<?php echo e(route('admin.business-settings.module.edit',[$module['id']])); ?>" title="<?php echo e(translate('messages.edit_Business_Module')); ?>"><i class="tio-edit"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer page-area pt-0 border-0">
                <!-- Pagination -->
                <div class="d-flex justify-content-center justify-content-sm-end">
                    <!-- Pagination -->
                    <?php echo $modules->links(); ?>

                </div>
                <!-- End Pagination -->
                <?php if(count($modules) === 0): ?>
                <div class="empty--data">
                    <img src="<?php echo e(asset('/public/assets/admin/svg/illustrations/sorry.svg')); ?>" alt="public">
                    <h5>
                        <?php echo e(translate('no_data_found')); ?>

                    </h5>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <div class="modal fade" id="warning-status-modal">
        <div class="modal-dialog modal-lg warning-status-modal">
            <div class="modal-content">
                <div class="modal-header pb-0">
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true" class="tio-clear"></span>
                    </button>
                </div>
                <div class="single-item-slider owl-carousel">
                    <div class="item">
                        <div class="modal-header pt-0">
                            <h2 class="modal-title"><?php echo e(translate('How does it works ?')); ?></h2>
                        </div>
                        <div class="modal-body">
                            <div class="how-it-works">
                                <div class="item">
                                    <img src="<?php echo e(asset('/public/assets/admin/img/how/how1.png')); ?>" class="h-60px object-contain object-left" alt="">
                                    <h2 class="serial"><?php echo e(translate('1')); ?></h2>
                                    <h5><?php echo e(translate('Create_Business_Module')); ?></h5>
                                    <p>
                                        <?php echo e(translate('To_create_a_new_business_module,_go_to:_‘Module_Setup’_→_‘Add_Business_Module.’')); ?>

                                    </p>
                                </div>
                                <div class="item">
                                    <img src="<?php echo e(asset('/public/assets/admin/img/how/how2.png')); ?>" class="h-60px object-contain object-left" alt="">
                                    <h2 class="serial"><?php echo e(translate('2')); ?></h2>
                                    <h5><?php echo e(translate('Add_Module_to_Zone')); ?></h5>
                                    <p>
                                        <?php echo e(translate('Go_to_‘Zone_Setup’→_‘Business_Zone_List’→_‘Zone_Settings’→_Choose_Payment_Method→Add_Business_Module_into_Zone_with_Parameters.')); ?>

                                    </p>
                                </div>
                                <div class="item mw-100">
                                    <img src="<?php echo e(asset('/public/assets/admin/img/how/how3.png')); ?>" class="h-60px object-contain object-left" alt="">
                                    <h2 class="serial"><?php echo e(translate('3')); ?></h2>
                                    <h5><?php echo e(translate('Create_Stores')); ?></h5>
                                    <p>
                                        <?php echo e(translate('Select_your_Module_from_the_Module_Section,_Click_→_’Store_Management’→’Add_Store’→Add_Store_details_&_select_Zone_to_integrate_Module+Zone+Store.')); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="modal-body py-0">
                            <div class="text-center ">
                                <h3 class="modal-title mb-3"><?php echo e(translate('Please go to settings and select module for this zone')); ?></h3>
                                <p class="txt">
                                    <?php echo e(translate("Otherwise this zone won't function properly & will work show anything against this zone")); ?>

                                </p>
                            </div>
                            <img src="<?php echo e(asset('/public/assets/admin/img/zone-settings-popup-arrow.gif')); ?>" alt="admin/img" class="w-100 h-unset">
                        </div>
                    </div>
                    <div class="item px-xl-4">
                        <div class="d-flex align-items-center">
                            <div class="col-sm-4 text-14">
                                <h4><?php echo e(translate('Make Sure')); ?></h4>
                                <p>
                                    <?php echo e(translate('All of your module details should be well-structured. Because those details are dynamically shown on the Landing page of your business.')); ?>

                                </p>
                            </div>
                            <div class="col-sm-8">
                                <img src="<?php echo e(asset('/public/assets/admin/img/module2.png')); ?>" alt="admin/img" class="w-100 h-unset">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-center pb-5">
                    <div class="slide-counter"></div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
    <script>
        "use strict";
        $(document).on('ready', function () {
            // INITIALIZATION OF DATATABLES
            // =======================================================

            // INITIALIZATION OF SELECT2
            // =======================================================
            $('.js-select2-custom').each(function () {
                let select2 = $.HSCore.components.HSSelect2.init($(this));
            });
        });
        $('#search-form').on('submit', function (e) {
            e.preventDefault();
            let formData = new FormData(this);
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.post({
                url: '<?php echo e(route('admin.business-settings.module.search')); ?>',
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                beforeSend: function () {
                    $('#loading').show();
                },
                success: function (data) {
                    $('.page-area').hide();
                    $('#table-div').html(data.view);
                    $('#itemCount').html(data.count);
                },
                complete: function () {
                    $('#loading').hide();
                },
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/ditokoku.id/ditokokuid-6ammart-laravel-admin/resources/views/admin-views/module/index.blade.php ENDPATH**/ ?>