<?php $__env->startSection('title', 'PPOB Transaction Report'); ?>

<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <style>
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }
        .stats-card:hover { transform: translateY(-5px); }

        .stats-card.success { background: linear-gradient(135deg, #28a745 0%, #20c997 100%); }
        .stats-card.warning { background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%); color: #212529; }
        .stats-card.danger { background: linear-gradient(135deg, #dc3545 0%, #fd7e14 100%); }
        .stats-card.info   { background: linear-gradient(135deg, #17a2b8 0%, #20c997 100%); }

        .chart-container, .filter-section {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .profit-positive { color: #28a745; font-weight: bold; }
        .profit-negative { color: #dc3545; font-weight: bold; }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="content container-fluid">
    <!-- Page Header -->
    <div class="page-header">
        <div class="row align-items-center">
            <div class="col-sm mb-2 mb-sm-0">
                <h1 class="page-header-title">
                    <span class="page-header-icon">
                        <img src="<?php echo e(asset('/public/assets/admin/img/chart.png')); ?>" class="w--20" alt="">
                    </span>
                    <span>PPOB Transaction Report</span>
                </h1>
            </div>
            <div class="col-sm-auto">
                <a class="btn btn--secondary" href="<?php echo e(route('admin.ppob.transactions.index')); ?>">
                    <i class="tio-back-ui"></i>
                    Back to Transactions
                </a>
            </div>
        </div>
    </div>

    <!-- Filter Section -->
    <div class="filter-section">
        <form method="GET" id="reportForm">
            <div class="row">
                <div class="col-md-3">
                    <label class="input-label">Date Range</label>
                    <select name="period" class="form-control" onchange="toggleCustomDate()">
                        <option value="today" <?php echo e($selectedPeriod == 'today' ? 'selected' : ''); ?>>Today</option>
                        <option value="yesterday" <?php echo e($selectedPeriod == 'yesterday' ? 'selected' : ''); ?>>Yesterday</option>
                        <option value="this_week" <?php echo e($selectedPeriod == 'this_week' ? 'selected' : ''); ?>>This Week</option>
                        <option value="last_week" <?php echo e($selectedPeriod == 'last_week' ? 'selected' : ''); ?>>Last Week</option>
                        <option value="this_month" <?php echo e($selectedPeriod == 'this_month' ? 'selected' : ''); ?>>This Month</option>
                        <option value="last_month" <?php echo e($selectedPeriod == 'last_month' ? 'selected' : ''); ?>>Last Month</option>
                        <option value="this_year" <?php echo e($selectedPeriod == 'this_year' ? 'selected' : ''); ?>>This Year</option>
                        <option value="custom" <?php echo e($selectedPeriod == 'custom' ? 'selected' : ''); ?>>Custom Range</option>
                    </select>
                </div>
                <div class="col-md-3" id="customDateRange" style="<?php echo e($selectedPeriod == 'custom' ? '' : 'display:none;'); ?>">
                    <label class="input-label">From Date</label>
                    <input type="date" name="from_date" class="form-control" value="<?php echo e(request('from_date')); ?>">
                </div>
                <div class="col-md-3" id="customDateRange2" style="<?php echo e($selectedPeriod == 'custom' ? '' : 'display:none;'); ?>">
                    <label class="input-label">To Date</label>
                    <input type="date" name="to_date" class="form-control" value="<?php echo e(request('to_date')); ?>">
                </div>
                <div class="col-md-3">
                    <label class="input-label">Status</label>
                    <select name="status" class="form-control">
                        <option value="">All Status</option>
                        <option value="Success" <?php echo e($selectedStatus == 'Success' ? 'selected' : ''); ?>>Success</option>
                        <option value="Pending" <?php echo e($selectedStatus == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="Failed" <?php echo e($selectedStatus == 'Failed' ? 'selected' : ''); ?>>Failed</option>
                    </select>
                </div>
                <div class="col-md-12 mt-3">
                    <button type="submit" class="btn btn--primary">
                        <i class="tio-filter-list"></i> Generate Report
                    </button>
                    <a href="<?php echo e(route('admin.ppob.transactions.report')); ?>" class="btn btn--secondary">
                        <i class="tio-refresh"></i> Reset
                    </a>
                </div>
            </div>
        </form>
    </div>

    <!-- Statistics Cards -->
    <div class="row gx-2 gx-lg-3 mb-3 mb-lg-2">
        <div class="col-md-3 col-sm-6 mb-3 mb-lg-2">
            <div class="card stats-card">
                <div class="card-body text-center">
                    <i class="tio-dollar-outlined" style="font-size: 2.5rem;"></i>
                    <h3><?php echo e(\App\CentralLogics\Helpers::format_currency($totalRevenue)); ?></h3>
                    <p>Total Revenue</p>
                    <small>(<?php echo e($totalTransactions); ?> transactions)</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-3 mb-lg-2">
            <div class="card stats-card success">
                <div class="card-body text-center">
                    <i class="tio-trending-up" style="font-size: 2.5rem;"></i>
                    <h3><?php echo e(\App\CentralLogics\Helpers::format_currency($totalProfit)); ?></h3>
                    <p>Total Profit</p>
                    <small><?php echo e($profitMargin); ?>% margin</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-3 mb-lg-2">
            <div class="card stats-card info">
                <div class="card-body text-center">
                    <i class="tio-checkmark-circle" style="font-size: 2.5rem;"></i>
                    <h3><?php echo e($successTransactions); ?></h3>
                    <p>Success</p>
                    <small><?php echo e($successRate); ?>% success rate</small>
                </div>
            </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-3 mb-lg-2">
            <div class="card stats-card warning">
                <div class="card-body text-center">
                    <i class="tio-clock-outlined" style="font-size: 2.5rem;"></i>
                    <h3><?php echo e($pendingTransactions); ?></h3>
                    <p>Pending</p>
                    <small>Need attention</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Charts -->
    <div class="row gx-2 gx-lg-3">
        <div class="col-lg-8 mb-3">
            <div class="chart-container">
                <h5>Monthly Profit Trend</h5>
                <canvas id="profitChart" height="300"></canvas>
            </div>
        </div>
        <div class="col-lg-4 mb-3">
            <div class="chart-container">
                <h5>Transaction Status</h5>
                <canvas id="statusChart" height="300"></canvas>
            </div>
        </div>
    </div>

    <!-- Top Products -->
    <div class="row gx-2 gx-lg-3">
        <div class="col-lg-12 mb-3">
            <div class="card">
                <div class="card-header border-0">
                    <h5>Top Profitable Products</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-borderless">
                        <thead class="thead-light">
                            <tr>
                                <th>Rank</th>
                                <th>SKU</th>
                                <th>Product</th>
                                <th>Transactions</th>
                                <th>Revenue</th>
                                <th>Cost</th>
                                <th>Profit</th>
                                <th>Margin</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>#<?php echo e($i+1); ?></td>
                                    <td><span class="badge badge-dark"><?php echo e($p->buyer_sku_code); ?></span></td>
                                    <td><?php echo e($p->product_name); ?></td>
                                    <td><?php echo e($p->total_transactions); ?></td>
                                    <td><?php echo e(\App\CentralLogics\Helpers::format_currency($p->total_revenue)); ?></td>
                                    <td class="text-muted"><?php echo e(\App\CentralLogics\Helpers::format_currency($p->total_cost)); ?></td>
                                    <td class="<?php echo e($p->total_profit >=0 ? 'profit-positive' : 'profit-negative'); ?>">
                                        <?php echo e(\App\CentralLogics\Helpers::format_currency($p->total_profit)); ?>

                                    </td>
                                    <td>
                                        <span class="badge <?php echo e($p->profit_margin >=20 ? 'badge-success' : ($p->profit_margin>=10 ? 'badge-warning':'badge-danger')); ?>">
                                            <?php echo e(number_format($p->profit_margin,2)); ?>%
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="8" class="text-center">No data</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Top Brands -->
    <div class="row gx-2 gx-lg-3">
        <div class="col-lg-12 mb-3">
            <div class="card">
                <div class="card-header border-0">
                    <h5>Top Brands Performance</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-borderless">
                        <thead class="thead-light">
                            <tr>
                                <th>Brand</th>
                                <th>Transactions</th>
                                <th>Revenue</th>
                                <th>Cost</th>
                                <th>Profit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $topBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($b->brand_name); ?></td>
                                    <td><?php echo e($b->total_transactions); ?></td>
                                    <td><?php echo e(\App\CentralLogics\Helpers::format_currency($b->revenue)); ?></td>
                                    <td class="text-muted"><?php echo e(\App\CentralLogics\Helpers::format_currency($b->cost)); ?></td>
                                    <td class="<?php echo e($b->profit >=0 ? 'profit-positive' : 'profit-negative'); ?>">
                                        <?php echo e(\App\CentralLogics\Helpers::format_currency($b->profit)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center">No data</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Monthly Summary -->
    <div class="row gx-2 gx-lg-3">
        <div class="col-lg-12 mb-3">
            <div class="card">
                <div class="card-header border-0">
                    <h5>Monthly Summary</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-borderless">
                        <thead class="thead-light">
                            <tr>
                                <th>Month</th>
                                <th>Transactions</th>
                                <th>Success Rate</th>
                                <th>Revenue</th>
                                <th>Cost</th>
                                <th>Profit</th>
                                <th>Avg Profit / Tx</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $monthlySummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($m->month_name); ?></td>
                                    <td><?php echo e($m->total_transactions); ?></td>
                                    <td>
                                        <span class="badge <?php echo e($m->success_rate>=90 ? 'badge-success':($m->success_rate>=70?'badge-warning':'badge-danger')); ?>">
                                            <?php echo e($m->success_rate); ?>%
                                        </span>
                                    </td>
                                    <td><?php echo e(\App\CentralLogics\Helpers::format_currency($m->total_revenue)); ?></td>
                                    <td class="text-muted"><?php echo e(\App\CentralLogics\Helpers::format_currency($m->total_cost)); ?></td>
                                    <td class="<?php echo e($m->total_profit >=0 ? 'profit-positive':'profit-negative'); ?>">
                                        <?php echo e(\App\CentralLogics\Helpers::format_currency($m->total_profit)); ?>

                                    </td>
                                    <td><?php echo e(\App\CentralLogics\Helpers::format_currency($m->avg_profit_per_transaction)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="7" class="text-center">No data</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script_2'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
<script>
function toggleCustomDate(){
    const period = document.querySelector('select[name="period"]').value;
    document.getElementById('customDateRange').style.display = period === 'custom' ? 'block' : 'none';
    document.getElementById('customDateRange2').style.display = period === 'custom' ? 'block' : 'none';
}

// Line Chart
new Chart(document.getElementById('profitChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: <?php echo json_encode($chartLabels, 15, 512) ?>,
        datasets: [
            {label: 'Revenue', data: <?php echo json_encode($revenueData, 15, 512) ?>, borderColor: '#667eea', backgroundColor: 'rgba(102,126,234,0.1)', tension: 0.4},
            {label: 'Profit',  data: <?php echo json_encode($profitData, 15, 512) ?>,  borderColor: '#28a745', backgroundColor: 'rgba(40,167,69,0.1)', tension: 0.4},
            {label: 'Cost',    data: <?php echo json_encode($costData, 15, 512) ?>,    borderColor: '#dc3545', backgroundColor: 'rgba(220,53,69,0.1)', tension: 0.4}
        ]
    },
    options: {responsive: true, plugins:{legend:{position:'top'}}, scales:{y:{beginAtZero:true}}}
});

// Pie Chart
new Chart(document.getElementById('statusChart').getContext('2d'), {
    type: 'doughnut',
    data: {
        labels: ['Success','Pending','Failed'],
        datasets: [{data: [<?php echo e($successTransactions); ?>, <?php echo e($pendingTransactions); ?>, <?php echo e($failedTransactions); ?>], backgroundColor:['#28a745','#ffc107','#dc3545']}]
    },
    options: {responsive:true, plugins:{legend:{position:'bottom'}}}
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/aaaa/Downloads/ditokokuid-6ammart-laravel-admin/resources/views/admin-views/ppob/transactions/report.blade.php ENDPATH**/ ?>