<div class="d-flex flex-wrap justify-content-between align-items-center mb-5 mt-4 __gap-12px">
    <div class="js-nav-scroller hs-nav-scroller-horizontal mt-2">
        <!-- Nav -->
        <ul class="nav nav-tabs border-0 nav--tabs nav--pills">
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('admin/business-settings/rental-email-setup/admin/provider-registration') ? 'active' : ''); ?>"
                href="<?php echo e(route('admin.business-settings.rental-email-setup', ['admin','provider-registration'])); ?>">
                    <?php echo e(translate('New Provider Registration')); ?>

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(Request::is('admin/business-settings/rental-email-setup/admin/withdraw-request') ? 'active' : ''); ?>"
                href="<?php echo e(route('admin.business-settings.rental-email-setup', ['admin','withdraw-request'])); ?>">
                    <?php echo e(translate('Withdraw Request')); ?>

                </a>
            </li>
        </ul>
        <!-- End Nav -->
    </div>
</div>
<?php /**PATH /www/wwwroot/ditokoku.id/ditokokuid-6ammart-laravel-admin/Modules/Rental/Resources/views/admin/business-settings/email-format-setting/partials/admin-email-template-setting-links.blade.php ENDPATH**/ ?>