<?php $__env->startSection('title',''); ?>


<?php $__env->startPush('css_or_js'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <style type="text/css" media="print">
        @page {
            size: auto;   /* auto is the initial value */
            margin: 0;  /* this affects the margin in the printer settings */
        }

    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin-views.order.partials._invoice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        function printDiv(divName) {
            window.open('<?php echo e(route("admin.order.print-invoice",["id" => $order->id])); ?>', '_blank');
        }

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /www/wwwroot/ditokoku.id/ditokokuid-6ammart-laravel-admin/resources/views/admin-views/order/invoice.blade.php ENDPATH**/ ?>