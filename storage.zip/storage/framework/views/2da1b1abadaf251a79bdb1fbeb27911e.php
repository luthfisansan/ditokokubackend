<div class="modal fade" id="activatedThemeModal" tabindex="-1" role="dialog" aria-labelledby="activatedThemeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" id="activateData">

        </div>
    </div>
</div>
<?php /**PATH /www/wwwroot/ditokoku.id/ditokokuid-6ammart-laravel-admin/resources/views/admin-views/system/addon/partials/activation-modal.blade.php ENDPATH**/ ?>